Phase 10.R-Q2 rerun with RevA-Q.

The uploaded DOCX asks to use RevA as the outer gate but replace binary RevA with a scored quaternionic falsification gate:
  RevA-Q = Qcoh + holonomy + residue-entropy - ablation-sensitivity terms.

This run applies RevA-Q to the existing Q2 synthetic/surrogate branch pipeline.
No zeta-zero test is performed.

Acceptance requires:
  base stability gates,
  component gates,
  RevA-Q score <= threshold.

Purpose:
  keep synthetic recovery high while forcing surrogate acceptance below the threshold.

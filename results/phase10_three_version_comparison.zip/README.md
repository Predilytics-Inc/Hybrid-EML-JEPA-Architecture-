Phase 10 three-version comparison.

Versions tested:
1. RevC_literal_U_theta_P_Ustar:
   Direct implementation of K_theta = U_theta P U_theta^*, with G_ij=exp[-alpha(lambda_i-lambda_j)^2]exp[-nu(lambda_i+lambda_j)],
   naive unfolding u=lambda/log(lambda), and Omega=pi.

2. RevA_corrected_local_diagnostic:
   Same U_theta P U_theta^* object as RevC, but evaluated with the corrected local/asymptotic diagnostics:
   empirical unit unfolding and Omega=pi*rank/N. This tests whether the explicit correlation-flow construction really resembles sine locally.

3. RevB_variational_constraint_kernel:
   A constraint-selected Fourier/projection multiplier learned from projection, binary, band, and mass constraints.
   The sine kernel is not used during constraint selection; it is used only as a post-hoc diagnostic.

Main result:
- RevC has exact projection behavior because UPU* is a projection, but this is not discriminative.
- RevA shows the explicit UPU* construction does not yet resemble the sine kernel locally.
- RevB gives the strongest path forward: it encodes the right constraints whose limiting translation-invariant projection is sine.

These numerical experiments do not prove RH, do not identify zeta zeros, and do not yet constitute a Hilbert-Polya realization.

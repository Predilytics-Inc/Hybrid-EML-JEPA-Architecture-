Phase 10.R-Q2. No zeta-zero testing. Synthetic planted systems and surrogate rejection using quaternionic branch states.

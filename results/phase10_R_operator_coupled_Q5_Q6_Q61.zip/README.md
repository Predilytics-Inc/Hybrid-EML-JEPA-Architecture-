# Operator-level finite-rank coupled kernel rerun

Implemented DOCX architecture shift:
A_ij(t)=a_i a_j cos(phi_i(t)-phi_j(t)); D_P(t)=det(I-A(t)).

Efficiency: cosine kernel is rank <= 2, so det(I-A) was computed exactly using the 2x2 matrix determinant lemma.

Branches:
1. operator_coupled_locked_drift: D(t)=exp(i theta0(t)) det(I-A(t)). This keeps the locked macro ADL drift and replaces only the independent product.
2. operator_coupled_strict_docx: D(t)=det(I-A(t)), the literal concrete DOCX code path.

Locked constants: lambda=0.025, beta=0.004, omega=0.42, alpha_ripple=0.015 sin(0.31 t).
P values: [197, 503, 1009, 2003]
No macro ADL retuning. No Q5/Q6/Q6.1 threshold changes. No zeta-zero anchoring.

Integrated gate: Q5 pass AND Q6 pass AND Q6.1 pass.
Overall verdict: FAIL

Implementation observation: for the literal real cosine kernel, det(I-A) stayed positive in the tested range because the largest rank-2 eigenvalue remained below 1, so the strict branch has essentially no lifted phase growth. The locked-drift branch preserves phase growth, but the interaction determinant does not yet generate residue-discriminating crossing topology under unchanged gates.

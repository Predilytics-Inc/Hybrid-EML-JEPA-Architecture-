Stronger ADL Step 4 rerun with integer winding index.

Construction:
  D(t) = exp(i(omega*t + beta*t^2 + small action ripple))
         * product_{p^k <= P} (1 - a_{p,k} exp(i(t * k log p/log P + phi_{p,k})))

Selected:
  P=197, lambda=0.04, beta=0.008, prime powers=59

Required gates:
  RevA v2 pass
  wrong-sign fail
  irregular anchor spacing

Verdict:
  PARTIAL/FAIL

Integer winding:
  k(t) = floor((Theta(t)-Theta(0))/pi)
  Jumps and clustering are reported in integer_winding_jumps.csv and winding_cluster_behavior.csv.

No zeta-zero anchoring or RH/Hilbert-Polya claim is made.

ADL Phase 4 determinant validation

Definition:
D_PK(s)=exp(-sum_{p<=P} sum_{k<=K} p^{-ks}/k)
D_PK(s)^(-1)=exp(sum_{p<=P} sum_{k<=K} p^{-ks}/k)

Correct log-derivative convention:
d/ds log D_PK(s)=L_PK(s)=sum log(p)p^{-ks}.
Equivalently, -d/ds log(D_PK(s)^(-1))=L_PK(s).
If one writes -d/ds log D_PK(s)=L_PK(s) while also requiring D_PK^{-1}≈zeta, the sign is reversed.

Files include determinant error statistics, convergence checks, representative time series, overlays, residuals, and pass/fail summary.
This validates the Euler determinant side only, not analytic continuation, critical-line structure, zeta zeros, or RH.

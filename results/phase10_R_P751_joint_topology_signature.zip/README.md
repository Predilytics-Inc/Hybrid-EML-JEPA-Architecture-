# P=751 joint topology signature micro-test

This run changed the observable only. It reused the residue-order zeta micro-test time series.

Joint signatures:
T_basic = (Delta k, sign(dTheta), 1[min |1-lambda| < 0.1])
T_gap = (Delta k, sign(dTheta), 1[min |1-lambda| < 0.1], jump_gap_bin)
T_strong = (Delta k, sign(dTheta), 1[min |1-lambda| < 0.1], 1[min |1-lambda| < 0.05], jump_gap_bin)

Strict joint prefilter:
Delta_scr > 0
min |1-lambda| < 0.1
joint entropy true < joint entropy scramble

Verdict: PASS_STRICT_JOINT_PREFILTER
Best kernel: delta2_log_ratio_sq
Best zeta: 0.1

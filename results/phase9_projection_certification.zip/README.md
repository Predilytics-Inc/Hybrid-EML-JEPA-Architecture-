Phase 9-9.5 projection certification suite.

Purpose:
Numerically test whether K_P behaves like a projection:
  K_P^2 ≈ K_P,
  eigenvalues collapse toward {0,1},
  Tr(K_P^2) ≈ Tr(K_P),
  random-vector idempotency is small,
  and the kernel is consistent with the sine/projection kernel.

Three variants:
1. literal_doc_unfold_maxnorm:
   Uses u=x/log(x) and K/max(|K|), matching the naive DOCX skeleton.
   This is included as a negative control. It fails because max-normalization is not
   a valid quadrature/projection normalization and the naive unfolding is not locally unit-density.

2. empirical_unfolded_sine:
   Uses central-window empirical unfolding u_i=i and the sine kernel
   K_ij=sin(Omega0(u_i-u_j))/(pi(u_i-u_j)).
   This is the actual numerical certification object. It passes the projection-like
   finite-window tests with projection error <0.05.

3. exact_fourier_projection_reference:
   Exact finite periodic Fourier projection used as a sanity reference.
   It has machine-precision projection error.

Settings:
P in {1000,5000,10000}; K_max=2; Omega0=0.65*pi.
Central windows N={120,180,240} are used to avoid edge effects and keep eigenvalue
diagnostics reproducible.

Important interpretation:
This certifies projection behavior for the unfolded band-limited kernel. It does not by
itself prove RH, identify zeta zeros, or establish a Hilbert-Polya operator.

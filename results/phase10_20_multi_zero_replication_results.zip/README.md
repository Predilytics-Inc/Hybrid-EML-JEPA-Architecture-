Phase 10.20 — Multi-Zero Local-Refinement Replication.

10.20a:
  Use known low zeta-zero ordinates only to define audit neighborhoods, not to tune parameters.
  Target zero neighborhoods: gamma_1, gamma_8, gamma_13, gamma_15, gamma_21.

10.20b:
  Fixed 10.19 law: plock_m010_p100_k1_phi0_s_halfpi.
  No retuning of lambda, pmax, kmax, phase-lock, determinant parameters, or gates.
  Local windows: [gamma-1, gamma+1].
  h values: 0.25, 0.125, 0.0625, 0.03125.

10.20c:
  Recompute determinant phase locally, detect phase-winding candidates, run OT and DTW branch reconstruction across N=20,24,28,32.
  OT/DTW costs do not use zeta-zero distance.

10.20z:
  Blind anchoring audit after branch construction.
  Gates: low refinement instability, Sref>=0.15, delta thresholds.
  Controls: phase_shuffled, wrong_sign, random_trace_zero, projection_only. Controls are not accepted after RevA.

Replication levels:
  Weak: >=3 target zeros accepted with delta<=0.5.
  Strong: >=3 target zeros accepted with delta<=0.1.
  Major: >=5 target zeros accepted with delta<=0.01 and monotone/non-increasing resolution improvement.

No RH proof or Hilbert-Polya claim is made.

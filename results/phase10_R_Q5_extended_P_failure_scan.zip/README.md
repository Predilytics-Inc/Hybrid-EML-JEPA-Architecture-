Q5 extended P failure scan.
Locked ADL + RevA v2-SF spectral-flatness gate.
No macro ADL retuning. Same lambda=0.025, beta=0.004, omega=0.42.
P values: [101, 127, 149, 173, 197, 223, 251, 307, 401, 503, 631, 751, 887, 1009, 1151, 1297, 1499, 1759, 2003, 2503, 3001, 4001, 5003]
Failure criterion: Delta_abl_min = min(F_zero-F_true, F_scramble-F_true) <= 0.
Worst P: 751 with Delta_abl_min=-0.03374373241188797.

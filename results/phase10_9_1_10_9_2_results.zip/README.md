Phase 10.9.1 and 10.9.2 separate anti-overfit validation.

10.9.1:
  Out-of-sample prime cutoffs P=[2000, 7000, 20000, 75000]
  using fixed 10.8.1 regime epsilon=0.4, mu=4.5, gamma=0.75, phase=pi.

10.9.2:
  Robustness grid over window shifts, alternative N, unfolding variants, and density observables.
  N=[20, 24, 28]
  unfoldings=['Ei', 'xi', 'p_over_logp']
  window sets=['base', 'shift5', 'shift10']
  density methods=['raw', 'affine_t']

Goal:
  prove the persistent track is not merely a tuning artifact.
No RH proof or zeta-zero identification is claimed.

Phase 6 zero-stability framework.

Grid:
sigma in [0.4,0.6], t in [0.5,50], P in {100,500,1000,5000,10000}, K=40.

Objects:
1) Center-normalized Phase 5 observable.
2) Sigma-average-removed de-smoothed observable.

Z(s)=d/ds log Xi(s) is approximated by sigma-derivative on the grid.
rho_P(t)=Im Z(1/2+it)/pi.

Structural result:
The current finite Phase 5 object has no true zeros away from gamma poles because it is
a nonzero exponential Euler factor times gamma factors. Phase 6 therefore detects
zero-like local minima and tracks their persistence; these are not proof-level zeros.

Main verdict:
Zero-like minima do not form a robust high-persistence family across P under this renormalization.
The density proxy shows partial but not complete stabilization.

Phase 10.22 split execution.

10.22A:
  True-law reconstruction only:
    plock_m010_p100_k1_phi0_s_halfpi
  Outputs:
    phase10_22A_true_branches.csv
    phase10_22A_target_summary.csv

10.22B:
  Phase controls:
    phase_shuffled
    wrong_sign
  Output:
    phase10_22B_phase_controls.csv

10.22C:
  Residue/projection controls:
    random_trace_zero
    projection_only
  Output:
    phase10_22C_residue_projection_controls.csv

10.22z:
  Final aggregation:
    accepted delta<=0.5: 15/20
    strong delta<=0.1: 8/20
    major delta<=0.01: 5/20
    controls accepted after RevA: 0
    verdict: MAJOR PASS

Targets:
  Excluded prior target indices:
    [1, 2, 3, 4, 5, 7, 8, 9, 11, 12, 13, 14, 15, 16, 21]
  Expanded held-out target indices:
    [6, 10, 17, 18, 19, 20, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35]

Fixed law:
  plock_m010_p100_k1_phi0_s_halfpi.
  No retuning.

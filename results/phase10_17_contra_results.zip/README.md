Phase 10.17-contra.

Goal:
  Test whether near-zeta raw hits systematically fail refinement stability.

Primary implication:
  delta <= 0.01 should imply Sref < 0.15, or high refinement drift.

Buckets:
  A: delta <= 0.01 and Sref < 0.15.
  B: delta <= 0.01 and Sref >= 0.15.
  C: delta > 0.01 and Sref >= 0.15.
  D: delta > 0.01 and Sref < 0.15.

This package uses the reconciled Phase 10.17 chain table as source of truth.
Null controls are reported from the Phase 10.17 RevA control table; controls are rejected by RevA and are not promoted to admissible chain-anchor status.

RevA v3 + modified non-fitted arithmetic residue law rerun.

Macro ADL form locked:
  D_P(t) = exp(i(omega t + beta t^2 + epsilon_alpha(t)))
           * product_(p^k <= P) (1 - a_(p,k) exp(i(t xi_(p,k) + phi_(p,k))))

Locked constants:
  lambda = 0.025
  beta = 0.004
  omega = 0.42
  alpha ripple = 0.015 sin(0.31 t)

P values:
  [197, 503, 1009, 2003]

Residue laws tested:
  ['baseline_old_residue', 'mobius_von_mangoldt', 'prime_pair_coupled', 'mobius_pair_coupled']

No macro ADL retuning.
No Q5/Q6/Q6.1 threshold changes.
No zeta-zero anchoring.

RevA v3 integrated gate:
  Q5 pass AND Q6 pass AND Q6.1 pass.

Overall verdict:
  FAIL

Best partial law:
  prime_pair_coupled

Interpretation:
  If this fails, the tested non-fitted residue laws still do not create enough residue-specific structure
  to separate true from scrambled controls under unchanged Q5/Q6/Q6.1 gates.

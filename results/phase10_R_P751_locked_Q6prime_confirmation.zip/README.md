# P=751 locked Q6′ confirmation

Locked candidate: P=751, delta2_log_ratio_sq, zeta=0.10, rho0=0.96, chi=0.25.

This package consolidates the exact-reduced determinant canary table and event-to-event bridge table into one locked confirmation table.

Four requested conditions:
1. Delta_scr > 0: False
2. min |1-lambda| < 0.1: True
3. H_joint,true < H_joint,scr: False
4. R_combined > 1.2: True

Status: NOT_PROMOTABLE

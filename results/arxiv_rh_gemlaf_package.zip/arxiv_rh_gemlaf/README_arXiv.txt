ArXiv submission package
========================

Files:
- main.tex: arXiv-ready manuscript
- references.bib: bibliography
- figures/: placeholder PDF figures

Before upload:
1. Replace placeholder figures with actual generated plots using the same filenames, or update figure paths.
2. Verify all numerical tables against final CSV outputs.
3. Optional: run pdflatex/bibtex locally to confirm compilation.
4. Upload main.tex, references.bib, and figures/ to arXiv as a single source package.

Important claim discipline:
- This manuscript does NOT claim RH.
- It does NOT claim a Hilbert-Polya operator.
- It reports persistent determinant phase tracks and non-identification with zeta zeros.

Phase 10.R variants split run. Conclusion: architecture revision before more zero-target testing.

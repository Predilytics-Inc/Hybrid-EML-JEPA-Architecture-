Phase 10.22V verification aggregate.

Verifies the five 10.22 major anchors: 10, 19, 23, 26, 29.

Required gates: delta <= 0.01, Sref >= 0.15, D_mean <= 0.5, D_max <= 1.0.

Implementation note: To keep the fine-grid verification feasible, this aggregate uses targeted branch-trace windows around the accepted 10.22 branch components rather than a full +/-1 zero-neighborhood rescan. Full raw candidate logs from the targeted windows are included.

Result: targets with major survival = 2/5; same five survive = False; verdict = VERIFICATION FAIL: SAME FIVE DO NOT SURVIVE.

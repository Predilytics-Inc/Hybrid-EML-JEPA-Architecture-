Phase 10.23 — Verified-Anchor Deepening

Protocol from attached DOCX:
  Use only the two surviving 10.22V anchors: zero indices 10 and 26.
  h = [0.0078125, 0.00390625, 0.001953125]
  N = [20, 24, 28, 32, 36]
  Same fixed law: plock_m010_p100_k1_phi0_s_halfpi.
  No retuning.

Acceptance:
  Delta <= 0.01
  Sref >= 0.15
  D_mean <= 0.5
  D_max <= 1.0

Stronger checks:
  Delta(h) non-increasing or bounded below 0.01.
  Delta(N) stable as N -> 36.

Control pressure:
  phase_shuffled, wrong_sign, random_trace_zero, projection_only.
  Controls accepted after RevA must equal zero.

Local window:
  [gamma-1, gamma+1] for both true and control models.

Result:
  PARTIAL CONTINUATION: ONLY ONE ANCHOR REMAINS

Interpretation:
  Zero 26 survives as a verified continuation under the 10.23 gates.
  Zero 10 remains stable and N36-present but loses Delta <= 0.01, so it is not retained as a major verified anchor.

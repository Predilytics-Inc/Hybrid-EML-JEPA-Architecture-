Phase 10.24 split run.

True-law full reconstruction completed for zero index 26 with fixed law, h=0.001953125,0.0009765625,0.00048828125, and N=20,24,28,32,36,40. It produced zero accepted branches.

Because the true-law required gate failed before control promotion, full control branch reconstruction was not completed in this environment. Control status files report the fixed RevA outcome: controls accepted after RevA = 0.

Final verdict: FAIL. Zero 26 did not survive the 10.24 true-law reconstruction gate.

Phase 10.9R and 10.10R repair experiments.

Core repair:
  RevA is evaluated on the effective determinant residue R_eff = gamma*cos(phase)*R,
  not on the raw residue R. This fixes the sign inconsistency that caused 10.9 false rejection
  when phase=pi.

Strict pass criteria:
  best_persistence_score > 0.9
  strong_tracks >= 1
  RevA_true_pass == True
  RevA_control_pass == False

10.9R:
  Repairs RevA-admissibility on one out-of-sample P-set:
  P={2000,7000,20000,75000}.

10.10R:
  Tests the repaired gate across two out-of-sample P-sets and robustness perturbations:
  A={2000,7000,20000,75000}
  B={3000,9000,30000,90000}
  N={20,24,28}; unfoldings={Ei,xi,p_over_logp}; window shifts={base,shift5,shift10};
  density methods={raw,affine_t}.

No RH proof or zeta-zero identification is claimed.

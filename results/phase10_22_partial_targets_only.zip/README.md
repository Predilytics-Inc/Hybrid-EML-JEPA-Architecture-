Phase 10.22 partial artifact.

10.22a completed: 20 expanded held-out zero targets were selected, excluding all prior 10.20/10.21 target indices.

10.22b/10.22z were attempted with the fixed law and local determinant reconstruction, but the full 20-target plus controls run exceeded the available execution limits before producing a validated branch table. No 10.22b/z numerical pass/fail should be inferred from this artifact.

Q4R-L RevA v2 immediate next steps. Synthetic tests plus finite prime arithmetic diagnostic. No zeta-zero anchoring or RH claim.

Phase 10.7 residue-strength and determinant-scaling search.

Goal: preserve the 10.6 RevA-admissible structure while scanning determinant parameters:
epsilon, mu, residue normalization gamma, and determinant phase/sign.

Pilot settings:
P=[1000, 10000, 50000], N=24, rank=8.
epsilon=[0.01, 0.05, 0.2, 0.5]; mu=[1.0, 2.0, 4.0, 8.0]; gamma=[1.0, 2.0]; phase=[0, pi].
t windows=[(0.5, 25), (25, 50), (50, 75)].

Best evaluated config:
config_id=5, epsilon=0.5, mu=4.0, gamma=1.0, phase=3.141592653589793.

Interpretation:
10.7 searches for a zero-producing determinant regime while preserving the 10.6 RevA gate.
It does not prove RH or identify zeta zeros.

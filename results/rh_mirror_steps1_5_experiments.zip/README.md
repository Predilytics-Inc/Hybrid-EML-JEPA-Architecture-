RH mirror framework Steps 1-5 certification suite.

Step 1:
Finite determinant-trace theorem check:
  -d/ds log D^{-1}_{P,K}(s) = sum_{p<=P,k<=K} log(p) p^{-ks}.
The experiment compares a finite-difference derivative to the direct trace.

Step 2:
Corrected renormalized block-Fredholm determinant:
  A_s = D_s T_ren D_{1-s};
  K_block = mu [[0,A_s],[A_{1-s},0]];
  Xi = det(I-K_block)=det(I-mu^2 A_s A_{1-s}).
Also compares against an unnormalized block baseline.

Step 3:
RevB projection/sine candidate construction by constrained Fourier multiplier.
Sine kernel is used only as a post-hoc diagnostic.

Step 4:
RevA falsification harness:
true arithmetic RevB, random sequence, perturbed primes, wrong unfolding, and RevC baseline.

Step 5:
Zero persistence and critical-line diagnostics:
phase-winding candidates, local-minimum fallback, candidate tracking across P.

Interpretation:
This is a Hilbert-Polya-grade certification path, not a proof of RH.
The finite determinant-trace identities are exact; the limiting operator and zero-identification remain conditional.

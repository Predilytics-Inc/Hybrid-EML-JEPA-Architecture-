ADL Phase 3 resolvent validation

Definition:
R_eta(z)=Tr(W(A-(z+i eta)I)^(-1))
        =sum_{p<=P} sum_{k<=K} log(p)/(k log(p)-(z+i eta)).

Tested:
P in {100,500,1000}, K=10, x in [0,10], eta in {1e-2,1e-3}.

Quantitative outputs:
- phase3_quantitative_summary.csv
- pole_localization_and_residue_all.csv
- real-axis profiles for P=1000
- full and zoom heatmaps for P=1000

Interpretation:
- Pole locations are validated on the regularized real-axis profile.
- Residues are validated with (lambda-(z+i eta))R_eta(z) at z=lambda.
- Dense prime-power lengths contaminate residues; isolated-pole statistics are the cleanest validation.
- This validates Euler-side meromorphic pole structure only, not zeros, RH, or analytic continuation.

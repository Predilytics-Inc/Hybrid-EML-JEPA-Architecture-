Phase 10.12a and 10.12z.

10.12a:
  Structural normalization / weighting / scale-law test.
  Only the determinant coordinate scale law x(u) is changed:
    linear, sqrt, square, log3, arcsine.
  No zeta zeros are used during selection.
  Selection is blind: persistence + RevA + density stability only.

10.12z:
  Blind zeta-zero anchoring / non-identification audit after 10.12a.
  Compares strict-pass strong tracks against known low zeta-zero ordinates.
  Reports both matches and nonmatches.
  Requires N-refinement improvement before any anchoring promotion.

No RH proof or Hilbert-Polya claim is made.

# Phase 10.17 Reconciliation Report

Source of truth: attached CSV files. The uploaded individual CSVs match the corresponding CSVs inside the ZIP package.

## Corrected top-level result

- conditions tested: 36
- condition verdicts: PASS=4, PARTIAL=32, FAIL=0
- refinement chains tested: 90
- low-refinement-instability chains: 0
- RSE accepted anchors: 0
- strict Sref accepted anchors: 0
- best Sref overall: 0.117072
- best raw zeta distance overall: 0.003296
- RevA true any: True
- RevA control any: False
- verdict: OOS NON-IDENTIFICATION

## Reconciliation note

The earlier prose claiming one RSE accepted anchor and one low-instability chain is not supported by the attached CSVs. The source CSVs report zero low-refinement-instability chains, zero RSE accepted anchors, and zero strict Sref anchors.

The best raw zeta proximity is extremely close, delta=0.003296, but it is not accepted because its refinement instability gate fails: mean refinement drift=0.612745 and max refinement drift=1.286765, exceeding the low-instability thresholds mean<=0.5 and max<=1.0.

Phase 10.R-Q3a/b/c — sign-orientation repair audit.

Protocol source: RH mirror step1-5_phase RevA-Q_10.R-Q3abc.docx.

10.R-Q3a diagnoses the accepted wrong-sign branch by adding:
  Delta_sign = corr(Delta phi_det, Delta phi_residue)
  Omega_orient = mean sign(Delta phi_det * Delta phi_residue)
  C_handed = mean[sign(Delta phi_det) == sign(Delta phi_residue)]

10.R-Q3b keeps all locked RevA-Q thresholds unchanged and adds only:
  primary gate: C_handed >= 0.65

10.R-Q3c reruns the minimal repair audit on the same Q3 branch/candidate datasets.
No zeta-zero testing is performed.

Final decision:
  Q3b FAIL: sign gate removes wrong-sign leak but over-tightens synthetic recovery; revise branch state, not just gate

P=751 ultrafast screen only. First-order trace-log screen and norm-bound eigen diagnostic. Verdict: FAIL. Best variant: left_drift_K_Dtheta_M. Runtime: 4.30s

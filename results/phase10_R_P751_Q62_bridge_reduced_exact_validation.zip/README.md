# P=751 Q6.2 -> Q6 bridge vs coarse exact reduced determinant validation

DOCX bridge setup:
- event mask: dist_to_one < 0.1
- Delta = 2 time steps
- de-overlap selected events by > 2*Delta
- same event windows for true and scramble
- local correlations aggregated over event windows

Candidate:
delta2_log_ratio_sq, zeta=0.1, rho0=0.96, chi=0.25

Validation:
Exact determinant of reduced low-rank kernel G(t), not a trace-log approximation.
This is intentionally not a full dense N x N determinant sweep.

Verdict:
NO_PASS

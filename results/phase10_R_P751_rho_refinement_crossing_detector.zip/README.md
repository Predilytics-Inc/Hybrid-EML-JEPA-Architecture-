# P=751 rho0 refinement crossing detector

Micro-test:
rho0 in [0.92, 0.94, 0.96]
chi in [0.25, 0.5]

Kernel:
theta drift term = theta0(t)*[(alpha_i-alpha_j)+chi*(alpha_i+alpha_j)/2]

Low-rank crossing detector:
P=751, r=5, M=2, small matrix size=25
No full determinant sweep.
No full Q5/Q6/Q6.1 run.

Strict prefilter:
Delta_scr > 0
min |1-lambda| < 0.1
H_true < H_scramble

Verdict: CROSSING_REACHED_NO_ENTROPY_SEPARATION
Best: rho0=0.96, chi=0.5

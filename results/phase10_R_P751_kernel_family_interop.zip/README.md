# P=751 kernel-family interoperability test

C_ij = exp(-delta_ij/delta0), delta0=1, lifted from prime-level kernels to prime-power states by base prime.

Families: delta1 rank-scale control; delta2 log-ratio-squared; delta3 entropic; delta4 index-log gamma=1.

Detector: P=751, N=156, rho0=0.96, chi=0.25, r=5, M=2, R_small=25.
No full determinant sweep. No full Q5/Q6/Q6.1 run.

Strict pass: Delta_scr>0, min |1-lambda|<0.1, H_true<H_scramble.

Verdict: CROSSING_ONLY_NO_ENTROPY
Best: delta2_log_ratio_sq; Delta_scr=0.001837835424461698; min_dist=0.04627507649193535; H_true=0.04049702375690303; H_scr=0.04049702375690303

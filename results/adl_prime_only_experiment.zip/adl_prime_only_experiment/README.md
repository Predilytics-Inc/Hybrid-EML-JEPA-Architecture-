# ADL prime-only numerical experiment

Parameters: `N=120`, primes up to `N` (`30` primes), `t=1.0`, trace powers `k=1..10`.

## Result

The literal PDF shift matrix is a divisibility-shift DAG on `1..N`. It has no closed cycles, so `Tr(U_t^k)=0` for all tested powers. Therefore the literal finite matrix does **not** realize the claimed prime trace.

The corrected cycle-ADL operator makes the primitive loops exactly primes by using the self-adjoint generator:

`A = diag(log p)`

and the unitary evolution:

`U_t = exp(i t A) = diag(p^(it))`.

Then

`Tr(U_t^k) = sum_p exp(i t k log p)`

to numerical precision.

## Summary

```json
{
  "parameters": {
    "N": 120,
    "num_primes": 30,
    "t": 1.0,
    "max_k": 10,
    "hybrid_epsilon": 0.55,
    "random_seed": 7
  },
  "literal_pdf_shift_U": {
    "nonzero_entries": 211,
    "max_abs_eigenvalue_of_U": 0.0,
    "max_abs_trace_U_powers": 0.0,
    "mean_trace_relative_error_vs_prime_sum": 0.9999999999997573,
    "H_pdf_eigen_min": -3.1279581395473026,
    "H_pdf_eigen_max": 3.127958139547303,
    "mean_abs_gap_H_eigen_to_log_prime": 0.771693817490715
  },
  "corrected_cycle_adl": {
    "dimension": 30,
    "max_trace_abs_error_vs_prime_sum": 1.1240459852675176e-14,
    "mean_trace_relative_error_vs_prime_sum": 1.4472761958187408e-15,
    "mean_abs_gap_A_eigen_to_log_prime": 0.0,
    "A_eigen_min": 0.6931471805599453,
    "A_eigen_max": 4.727387818712341
  },
  "representative_hybrid_injection": {
    "dimension": 30,
    "max_trace_abs_error_vs_prime_sum": 7.810132336591796,
    "mean_trace_relative_error_vs_prime_sum": 1.0226254053592005,
    "mean_abs_gap_H_eigen_to_log_prime": 0.032404345945151826,
    "H_eigen_min": 0.6458283335978137,
    "H_eigen_max": 4.964414309514798
  }
}
```

import numpy as np

def primes_upto(n):
    sieve = [True]*(n+1)
    sieve[0:2] = [False, False]
    for i in range(2, int(n**0.5)+1):
        if sieve[i]:
            for j in range(i*i, n+1, i):
                sieve[j] = False
    return [i for i in range(n+1) if sieve[i]]

def build_pdf_shift(N=120, t=1.0):
    P = primes_upto(N)
    U = np.zeros((N, N), dtype=np.complex128)
    for p in P:
        phase = np.exp(1j*t*np.log(p))
        for m in range(1, N//p + 1):
            n = p*m
            U[n-1, m-1] += phase
    H = 0.5*(U + U.conj().T)
    return P, U, H

def build_corrected_cycle_adl(P, t=1.0):
    logs = np.log(np.array(P, dtype=float))
    A = np.diag(logs)
    U = np.diag(np.exp(1j*t*logs))
    return A, U

def trace_powers(U, max_k=10):
    out = []
    cur = np.eye(U.shape[0], dtype=np.complex128)
    for k in range(1, max_k+1):
        cur = cur @ U
        out.append(np.trace(cur))
    return np.array(out)

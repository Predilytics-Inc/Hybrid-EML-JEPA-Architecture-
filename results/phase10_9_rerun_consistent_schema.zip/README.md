Phase 10.9.1 and 10.9.2 rerun with one consistent output schema.

Requested schema:
  track_count, strong_tracks, mean_drift, RevA_true_pass, RevA_control_pass.

Definitions:
  track_count = number of cross-P candidate tracks.
  strong_tracks = tracks with persistence_score > 0.7, mean_delta < 0.35, and at least two phase-winding hits.
  mean_drift = best-track mean_delta, i.e. the smallest mean cross-P candidate drift among tracks.
  RevA_true_pass = true candidate passes the residue RevA gate.
  RevA_control_pass = any negative control passes the RevA gate.

10.9.1:
  out-of-sample P=[2000, 7000, 20000, 75000], N=24, unfolding=Ei, density=raw.

10.9.2:
  robustness grid over N=[20, 24, 28], unfoldings=['Ei', 'xi', 'p_over_logp'], window shifts=['base', 'shift5', 'shift10'],
  density methods=['raw', 'affine_t'].

Fixed determinant regime:
  epsilon=0.4, mu=4.5, gamma=0.75, phase=pi.

No RH proof or zeta-zero identification is claimed.

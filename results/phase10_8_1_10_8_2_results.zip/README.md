Phase 10.8.1 and 10.8.2 separate runs.

10.8.1:
  Local parameter refinement around the 10.7 seed regime:
    epsilon=0.5, mu=4.0, gamma=1.0, phase=pi.
  Goal: reduce raw determinant density drift while preserving the strong phase-winding track.

10.8.2:
  Density stabilization observable applied to top 10.8.1 configurations:
    raw, mean-centered, affine-in-t detrended, z-scored density.
  Goal: reduce density drift without changing the determinant phase-winding tracks.

Pilot settings:
  P=[1000, 10000, 50000], N=24, rank=8.
  No RH proof or zeta-zero identification is claimed.

Phase 10.6 projector + trace-zero arithmetic residue determinant.

Corrected construction:
  K_proj is fixed as the canonical centered Fourier projection / sine-CLT layer.
  R_arith is constructed from the OLC prime residue and projected orthogonally to span{I, K_proj},
  making it trace-zero and projection-orthogonal.
  The determinant-level object is:
    Xi_P,eps(s) = det(I - mu^2 A_s A_(1-s)),
    A_s = D_s (K_proj + eps R_arith,P) D_(1-s).

Pilot settings:
  P=[1000, 5000, 10000, 50000], N=40, rank=14, eps_grid=[0, 0.01, 0.02, 0.05, 0.1, 0.2, 0.35].
  Best candidate: model=universal_residue, epsilon=0.01.

Interpretation:
  10.6 separates the universal projection/sine/CLT layer from the arithmetic residue layer.
  It does not prove RH or identify zeta zeros. Zero persistence is only promoted if the RevA residue gate passes uniquely.

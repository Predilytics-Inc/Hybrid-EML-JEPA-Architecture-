Phase 10 Q4R-L ADL P-stability rerun.

P values:
  [197, 503, 1009, 2003]

Locked ADL form:
  D(t) = exp(i(omega*t + beta*t^2 + 0.015 sin(0.31t)))
         * product_(p^k <= P) (1 - a_(p,k) exp(i(t xi_(p,k) + phi_(p,k))))

Primary locked parameters:
  lambda=0.025, beta=0.004

Archive consistency audit:
  lambda=0.040, beta=0.008

Required gates:
  RevA v2 pass for each P
  wrong-sign fail for each P
  anchor spacing CV nonzero and stable
  integer winding jump structure stabilizes

Primary verdict:
  PARTIAL/FAIL

No zeta-zero anchoring, RH claim, or Hilbert-Polya claim is made.

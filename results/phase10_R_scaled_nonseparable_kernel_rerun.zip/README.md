# Scaled nonseparable sum-phase sine operator repair
Psi_ij = phi_i - phi_j + eta sin(phi_i + phi_j), eta=0.15.
gP = rho0 / ||A||_2 with rho0=0.6.
K = gP A exp(i Psi).
No macro ADL retuning, no threshold changes, no zeta anchoring.
Eigen diagnostic uses fixed-dimensional Ritz projection for speed; gate determinant uses first-order trace-log screening.
Overall verdict: FAIL. Best branch: strict_operator.

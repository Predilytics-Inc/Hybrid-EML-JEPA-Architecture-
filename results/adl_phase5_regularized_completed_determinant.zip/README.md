Phase 5 regularized completed determinant.

Definitions:
D_PK^{-1}(s)=exp(sum_{p<=P,k<=K} p^{-ks}/k).
Lambda_PK(s)=pi^{-s/2} Gamma(s/2) D_PK^{-1}(s).
Dual raw object Xi_raw(s)=Lambda_PK(s)Lambda_PK(1-s).
Regularized object Xi_reg(s)=Xi_raw(s)/Xi_raw(1/2).

This implements the Phase 5 idea with a center counterterm. The t=0 dual singular point
at s=1 is excluded from symmetry/stability tests because Gamma((1-s)/2) has a pole there.
Results validate formal s<->1-s symmetry and K-saturation, while showing that P-stability
in the strip remains only partial. This is not an analytic continuation theorem or RH claim.

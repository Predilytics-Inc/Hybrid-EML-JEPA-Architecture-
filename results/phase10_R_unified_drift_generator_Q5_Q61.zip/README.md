Unified drift-generator attempt. Critical result: det(I-Dtheta M Dtheta^-1)=det(I-M), so drift conjugation is spectrally/determinant invisible. Verdict: FAIL

# P=751 chi sweep mixed-anisotropy low-rank crossing detector

Tested chi in [0.0, 0.25, 0.5, 0.75, 1.0]; requested new values are [0.5, 0.75, 1.0].
Pass condition locked: Delta_scr(751)>0, min |1-lambda|<0.1, H_true < H_scr.
No full determinant sweeps. No full Q5/Q6/Q6.1 runs.
Verdict: PARTIAL_RESIDUE_SIGNAL_ONLY
Best new chi: 0.5

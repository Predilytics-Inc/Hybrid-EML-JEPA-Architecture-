RevA v3 dynamic residue transport rerun.

Recommended move implemented:
  replace static phi_(p,k)(P) with arithmetic time-dependent phi_(p,k)(P,t),
  so residue structure can move symbolic winding crossings.

Macro ADL form locked:
  D_P(t) = exp(i(omega t + beta t^2 + epsilon_alpha(t)))
           * product_(p^k <= P) (1 - a_(p,k) exp(i(t xi_(p,k) + phi_(p,k)(P,t))))

Locked constants:
  lambda = 0.025
  beta = 0.004
  omega = 0.42
  alpha ripple = 0.015 sin(0.31 t)
  transport_gamma = 1.0

P values:
  [197, 503, 1009, 2003]

Residue laws tested:
  ['baseline_static_old', 'dyn_mobius_transport', 'dyn_vonmangoldt_transport', 'dyn_prime_pair_transport', 'dyn_mobius_pair_transport']

No macro ADL retuning.
No Q5/Q6/Q6.1 threshold changes.
No zeta-zero anchoring.

Integrated gate:
  Q5 pass AND Q6 pass AND Q6.1 pass.

Overall verdict:
  FAIL

Best partial law:
  dyn_vonmangoldt_transport

Interpretation:
  If this fails, the tested phi_(p,k)(P,t) transport laws still do not create enough residue-specific symbolic winding structure
  to separate true from scrambled controls under unchanged Q5/Q6/Q6.1 gates.

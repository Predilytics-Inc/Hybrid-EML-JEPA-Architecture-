DOCX Step 1-4 rank-2 spectral feedback P751. Verdict: FAIL

Phase 7 cancellative models.

Model A: subtractive log model.
H_P,K(s)=pi^(-s/2)Gamma(s/2)+logZ_P,K(s)-C_P,K(s).
C_P,K(s)=sum_k 1/k int_2^P x^(-ks)/log(x) dx.
F_sub(s)=H(s)-H(1-s). P=[100, 500, 1000, 5000, 10000], K=10.

Model B: GEMLA Fredholm determinant.
Prime-power ADL basis |p,k>, lambda=k log p.
G_ij=exp[-alpha(lambda_i-lambda_j)^2]-log(1+beta|lambda_i+lambda_j|), with envelope exp[-nu(lambda_i+lambda_j)].
A_s=D_s G D_(1-s). det(I-K_s), K_s=mu [[0,A_s],[A_(1-s),0]], evaluated as det(I-mu^2 A_s A_(1-s)).
Low-rank rank=24. P=[100, 500, 1000], K=2, mu=2.0, alpha=0.12, beta=0.05, nu=0.035.

Grid: sigma [0.4, 0.6], t [0.5, 50.0].
These finite experiments do not prove RH or zeta-zero recovery.

Phase 10.R-Q6.1 — Integer Winding Entropy.

Locked ADL:
  P = [197, 503, 1009, 2003]
  lambda = 0.025
  beta = 0.004
  omega = 0.42
  No retuning.

Implemented DOCX gate:
  dk = diff(floor((Theta - Theta[0]) / pi))
  H = entropy(dk)
  H2 = block_entropy(dk, L=3)
  Hr = run_length_entropy(run_lengths(dk))
  alignment = mean cross-P equality of dk sequences

Gate:
  H_true < H_scramble
  H2_true < H2_scramble
  Hr_true < Hr_scramble
  align_true > align_scramble
  align_true > 0.75

Verdict:
  FAIL

No zeta-zero anchoring, RH claim, or Hilbert-Polya claim is made.

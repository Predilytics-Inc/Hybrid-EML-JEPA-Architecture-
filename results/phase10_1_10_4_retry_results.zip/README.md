Phase 10.1-10.4 retry results.

10.1 LDR: tests old xi=log(p)/log(P), analytic LDR u=Ei(log p), and empirical unfolding.
10.2 IKR: compares raw x-kernel, LDR geometry kernel, and intrinsic local-metric kernel.
10.3 OLC: subtracts continuous equal-density operator and measures trace-log invariant drift.
10.4 SCFP: PyTorch fixed-point learns one spectral multiplier across all P.

These are pilot-scale experiments using P={1000,5000,10000}, N=48.
No RH proof, no zeta-zero identification, and no completed Hilbert-Polya realization are claimed.

# P=751 event-to-event second-order bridge

Implements DOCX items 7 and 9:
- Add adjacent event-to-event correlation coherence.
- Also compute optional event sign-consistency term.

Event selection:
E_q(t)=1[ |1-lambda(t)| <= Q_q(|1-lambda|) ], q=[0.05, 0.1, 0.2]
De-overlap: selected events separated by > 2*Delta, Delta=2
Same event windows used for true and scramble.

Local ratio:
mean |corr(f, g)| true / mean |corr(f, g)| scramble

Event-pair ratio:
mean |corr(f[event_i], f[event_i+1])| true / same scramble

Combined ratio:
local_ratio * event_pair_ratio

Verdict:
EVENT_PAIR_BRIDGE_PASS_CANARY_UNVERIFIED

# Non-factorizable arithmetic phase step 1–4 rerun

Requested phase:
Psi_ij(t)=t*(xi_i-xi_j)+eta*log(p_i)*log(p_j)/log(P), eta=0.1.

Step 1 conclusion:
The arithmetic term is non-factorizable in index space, but it is time-independent. Therefore
K_ij(t)=a_i a_j C_ij exp(i Psi_ij(t)) = D_xi(t) B D_xi(t)^(-1),
where B_ij=a_i a_j C_ij exp(i eta log(p_i)log(p_j)/log(P)).
So the proposal does NOT break time-conjugacy. Eigenvalues are invariant in t.

Step 2 failure band:
Tested P=[751, 197, 1009]. Eigenvalue diagnostic failed for all.

Step 3 diagnostics:
(A) eigenvalue motion: failed.
(B) Delta_scr(P): zero for the locked-drift derivative diagnostics.
(C) winding entropy: true did not drop below scramble.

Step 4 full Q5 -> Q6 -> Q6.1:
No macro ADL retuning. No threshold changes. No zeta-zero anchoring.
Integrated gate = Q5 pass AND Q6 pass AND Q6.1 pass.
Overall verdict: FAIL.

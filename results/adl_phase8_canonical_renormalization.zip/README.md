Phase 8 canonical renormalization experiment.

xi_p,k=k log(p)/log(P), with K=1 so xi in [0,1].

Tested literal formula K_s=D_s T D_(1-s), Xi=det(I-K_s), and corrected block Fredholm Xi=det(I-mu^2 A_s A_(1-s)).

The literal formula is essentially s-independent by determinant cyclicity. The corrected block model preserves xi renormalization while retaining nontrivial s-dependence.

P=[1000, 5000, 10000], rank=10, alpha=8.0, beta=0.1.

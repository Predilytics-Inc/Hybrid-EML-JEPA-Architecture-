Phase 10.13: zeta-native scale law from the explicit formula.

10.13a:
  Derived structural scale laws from the smooth Riemann-von Mangoldt zero-counting term:
    Nbar(T)=T/(2pi)log(T/(2pi))-T/(2pi)+7/8.
  Tested:
    linear baseline,
    rvm_count,
    rvm_quantile,
    rvm_density_weight,
    rvm_hybrid.
  Zeta-zero ordinates are NOT used during scale-law selection.
  Selection remains blind: persistence + RevA + density stability.

10.13z:
  After blind selection, persistent strict-pass tracks are audited against known zeta-zero ordinates.
  Strong anchor threshold: |mean_t - nearest gamma_n| <= 0.5.
  Promotion also requires N-refinement improvement.

No RH proof or Hilbert-Polya claim is made.

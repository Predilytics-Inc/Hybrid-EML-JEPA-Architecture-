# ADL v2 closed prime-cycle + Gamma-EML-alpha perturbation experiments

Core:
H0 |p> = log(p) |p>, U_t = exp(i t H0).

Exact unperturbed finite identity:
Tr(U_t^k) = sum_p exp(i t k log p).

Perturbation:
H_epsilon = H0 + epsilon V
where V is a real symmetric zero-diagonal deterministic EML-action kernel on normalized log-prime coordinates.

Zero diagonal means the trace error is second-order at small epsilon.

Files:
- trace_by_k.csv
- trace_error_summary.csv
- spacing_statistics.csv
- eigenvalues_and_drifts.csv
- perturbation_stability_summary.csv
- explicit_formula_behavior.csv
- trace_error_vs_epsilon.png
- eigen_drift_vs_epsilon.png
- spacing_ks_vs_epsilon_p1000.png
- spacing_hist_p1000_eps_*.png
- chebyshev_psi_prime_power_staircase.png

Note:
The explicit-formula experiment tests the Euler/prime-power side in Re(s)>1 and the Chebyshev psi staircase. It does not recover the zero side or prove RH.

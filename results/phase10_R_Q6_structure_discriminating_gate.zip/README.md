Phase 10.R-Q6 — Structure-Discriminating Gate.
Locked ADL with P=[197, 503, 1009, 2003], lambda=0.025, beta=0.004, omega=0.42; no retuning.
Q6 features: correlation persistence, phase coherence, curvature structure, and cross-P transport.
Integration rule: Q5_pass AND Q6_pass.
Verdict: Q6 FAIL.
No RH, zeta-zero identification, or Hilbert-Polya claim is made.

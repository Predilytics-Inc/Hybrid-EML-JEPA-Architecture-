Phase 10.R-Q4 — Handedness-aware quaternionic state.

Goal:
  Encode determinant/residue handedness inside branch continuation rather than using the hard Q3b sign gate.

State:
  old quaternionic state plus:
    chi_orient = cos(det_phase - residue_phase)
    eta_hand = sign(sin(det_phase-ref_phase)*sin(residue_phase-ref_phase))

Variants:
  Q4-lite: w_chi=0.25, w_eta=0.25
  Q4-main: w_chi=0.50, w_eta=0.50
  Q4-strong: w_chi=0.75, w_eta=0.75

RevA-Q:
  Thresholds frozen from Q3.
  No hard sign gate used.
  Candidate dataset reused from Q3.

Selection rule:
  choose weakest variant that repairs wrong-sign leakage, keeps every surrogate FPR <= 2%, and preserves planted/sine/GUE recovery >=80% with <=10% drop.

Selected variant:
  none

Verdict:
  Q4 FAIL: revise handedness state or branch law

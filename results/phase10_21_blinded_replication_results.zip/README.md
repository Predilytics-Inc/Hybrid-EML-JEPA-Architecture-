Phase 10.21 — Blinded Multi-Zero Replication Expansion.

Goal:
  Test whether the Phase 10.20 behavior replicates on zero neighborhoods not used in 10.20.

Blinded target set:
  zero indices 2,3,4,5,7,9,11,12,14,16.
  Excluded 10.20 indices: 1,8,13,15,21.

Fixed law:
  plock_m010_p100_k1_phi0_s_halfpi.
  No retuning of law, determinant parameters, thresholds, or OT/DTW costs.

Procedure:
  For each target zero neighborhood:
    local window [gamma-1, gamma+1],
    h = 0.25, 0.125, 0.0625, 0.03125,
    recompute determinant phase,
    detect phase-winding candidates,
    reconstruct branches with OT/DTW across N=20,24,28,32,
    compute anchoring and stability afterward.

Acceptance gates:
  low refinement instability,
  delta <= 0.5,
  Sref >= 0.15,
  RevA admissible true law.

Strong blinded anchor:
  delta <= 0.1.

Major blinded anchor:
  delta <= 0.01.

Controls:
  phase-shuffled, wrong-sign phase-lock, random trace-zero residue, projection-only/no-residue.
  Controls may produce raw pre-RevA candidates but are not accepted after RevA.

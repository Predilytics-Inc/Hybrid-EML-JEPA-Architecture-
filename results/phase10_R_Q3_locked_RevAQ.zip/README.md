Phase 10.R-Q3 — Locked RevA-Q rerun.

Goal:
  Freeze RevA-Q thresholds and rerun Q2 without changing gates.

Threshold version:
  RevA-Q-v1_locked_from_10.R-Q2

Changed?
  no

Synthetic set:
  planted determinant,
  sine-kernel synthetic,
  GUE sample,
  perturbed planted determinant.

Surrogate set:
  randomized prime-like,
  circularly shifted von Mangoldt,
  scrambled von Mangoldt,
  same-density randomized phase,
  projection-only,
  phase-shuffled,
  wrong-sign phase-lock,
  Poisson synthetic.

Pass criteria:
  planted determinant recovery >= 90%
  sine-kernel recovery >= 90%
  GUE recovery >= 80%
  every surrogate FPR <= 2%

Verdict:
  Q3 LOCKED-GATE FAIL

No zeta-zero testing is performed.

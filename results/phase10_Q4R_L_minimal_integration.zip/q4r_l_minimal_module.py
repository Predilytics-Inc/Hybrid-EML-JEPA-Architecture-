# Q4R-L minimal module
# See CSV checklist for integration audit.

Q4R-L minimal integration audit. Validates lifted phase, dTheta RevA, Theta mod pi anchors, and no DTW/beam pruning. Synthetic determinant test only; no zeta-zero claim.

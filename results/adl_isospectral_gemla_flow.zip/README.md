ADL isospectral Γ–EML–α flow experiment

H0 = diag(log p)
G = Hermitian Γ–EML–α / EML-action kernel over normalized log-prime coordinates
Uθ = exp(-i θ G)
Hθ = Uθ H0 Uθ*

Preserved:
- spectrum(Hθ) = spectrum(H0)
- Tr(Hθ^k) = Tr(H0^k)
- spectral form factor |Tr(exp(i τ Hθ))|^2 / N

Changed:
- eigenvectors in the prime basis
- basis-dependent transition amplitudes and observables

This isospectral flow preserves arithmetic trace exactly but cannot change eigenvalue spacing statistics.

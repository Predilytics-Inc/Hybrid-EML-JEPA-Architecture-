Phase 10.5A true projection-algebra fixed-point experiment.

This implements option A after Phase 10 retry:
- starts from LDR + OLC counterterm operator,
- applies hard spectral projection,
- iterates a universal cross-P projection fixed point,
- compares against OLC-only and RevC negative-control baselines.

Pilot settings: P={1000,5000,10000}, N=40, rank≈0.35N.

No RH proof or zeta-zero identification is claimed. This tests whether hard projection algebra repairs the failed soft SCFP layer.

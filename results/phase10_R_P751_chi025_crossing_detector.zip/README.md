# P=751 chi=0.25 mixed-anisotropy crossing detector

Tested adjustment alpha_ij = (log p_i-log p_j)/log P + chi(log p_i+log p_j)/(2 log P) with chi=0.25.
Baseline chi=0 included as comparator.
No full determinant sweeps. No full Q5/Q6/Q6.1 run.

P=751, N=156, r=8, M=2, eta=0.15, rho0=0.6, gP=100.14702840099822
Verdict: TOPOLOGY_PRESENT_BUT_NOT_PROMOTABLE
chi=0 min dist: 0.4034336459061952
chi=0.25 min dist: 0.40386296600721017
chi=0.25 delta_scr: 0.004976341866211431

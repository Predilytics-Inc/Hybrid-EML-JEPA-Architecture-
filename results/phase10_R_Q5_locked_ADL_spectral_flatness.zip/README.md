Phase 10.R-Q5 — locked ADL + RevA v2-SF spectral-flatness gate.

Locked ADL:
  lambda=0.025
  beta=0.004
  omega=0.42
  alpha ripple=0.015 sin(0.31 t)
  P=[197, 503, 1009, 2003]
  No retuning.

Computed for each P:
  Theta_P(t), dTheta_P(t), rho_P(t), F_P, Delta_abl(P), k_P(t).

Flatness:
  rho = dTheta/pi
  rho_tilde = rho / mean(abs(rho))
  F = ||rho_tilde - mean(rho_tilde)||_2/||rho_tilde||_2
      + eta ||d rho_tilde/dt||_2/||rho_tilde||_2

Ablation:
  Delta_abl_zero = F(residue_zero_ablation) - F(true)
  Delta_abl_scramble = F(residue_scramble_ablation) - F(true)
  required: min(delta zero, delta scramble) > 0 for each P.

Verdict:
  PARTIAL/FAIL

No zeta-zero anchoring, RH claim, or Hilbert-Polya claim is made.

Phase 10.18 — Branch Continuation Repair.

Goal:
  Test whether 10.17-contra failure was intrinsic or caused by poor nearest-neighbor matching across N.

Input:
  Fixed 10.17 setup, fixed law, no retuning.
  Candidate clouds use phase-winding candidates only from Phase 10.17.

Methods:
  10.18a OT:
    Sequential Hungarian matching between adjacent N levels using candidate features:
      t, sigma, winding sign, logdet depth, condition persistence.
    The cost never uses zeta-zero distance.

  10.18b DTW:
    Beam-search dynamic-time-warp continuation allowing gaps and curvature penalty.
    The objective never uses zeta-zero distance.

  10.18z:
    After branches are constructed, compute zeta anchoring:
      delta, mean drift, max drift, Sref.
    Apply gates:
      RevA true, no RevA control, low refinement instability, delta <= 0.5.
    Strict promotion also requires Sref >= 0.15.

Success levels:
  Partial: stable accepted anchor at delta <= 0.5.
  Strong pass: delta <= 0.1 and Sref >= 0.15.
  Major pass: delta <= 0.01 and Sref >= 0.15.

No RH proof or Hilbert-Polya claim is made.

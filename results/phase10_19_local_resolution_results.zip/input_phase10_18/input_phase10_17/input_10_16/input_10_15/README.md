Phase 10.15: Refinement-Stability Enforcement (RSE).

Inputs:
  Phase 10.14 oscillatory explicit-formula outputs.

10.15a:
  Reuses the 10.14a scan and adds cross-N continuity across N=20,24,28.
  For each P_set and scale_law, N=20 tracks are matched to nearest mean_t tracks at N=24 and N=28.
  Sref = N_coverage * mean_internal_P_persistence * exp(-mean_refinement_drift).

Definitions:
  low_refinement_instability:
    full N=20,24,28 chain
    mean refinement drift <= 0.5
    max refinement drift <= 1.0

10.15z:
  Stability-filtered anchoring accepts a chain only if:
    RevA true passes for all constituent conditions,
    no RevA control passes,
    low_refinement_instability is true,
    abs_delta_to_nearest_zeta_zero <= 0.5.

A stricter diagnostic accepted_strict_Sref_anchor additionally requires Sref >= 0.15.

Interpretation:
  RSE accepted anchors are drift-stable raw anchors.
  strict_Sref accepted anchors require both refinement stability and nontrivial within-P persistence.
  No RH proof or Hilbert-Polya claim is made.

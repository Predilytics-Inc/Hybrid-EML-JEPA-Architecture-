Phase 10.14: oscillatory explicit-formula correction.

10.14a:
  Start from the zeta-native rvm_quantile scale law and add a prime-side oscillatory correction
  inspired by explicit formula terms:
    sum_{p^k} Lambda(p^k)/sqrt(p^k) cos(T k log p),
  with damping and small amplitude.
  No zeta-zero ordinates are used during selection.
  Selection remains blind: persistence + RevA + density stability.

10.14z:
  After blind selection, strict-pass strong tracks are compared to known low zeta-zero ordinates.
  Anchoring promotion requires:
    |mean_t - nearest gamma_n| <= 0.5,
    RevA true pass,
    RevA control rejection,
    and N-refinement improvement.

This remains an experimental falsification/validation pipeline, not an RH proof.

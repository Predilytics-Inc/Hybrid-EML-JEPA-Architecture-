Phase 10.16: phase-lock the oscillatory correction to improve Sref without fitting zeta zeros.

Method:
  The 10.14/10.15 oscillatory correction cos(T k log p) was generalized to:
    cos(T k log p + phi0 + slope*(T-Tmid)/Trange).
  phi0 and slope were selected blindly by internal RSE score Sref only.
  Zeta-zero ordinates are used only after selection, in 10.16z anchoring audit.

10.16a:
  Run phase-locked oscillatory scan over:
    baseline rvm_quantile,
    10.15 accepted families,
    constant phase offsets ±pi/4, ±pi/2,
    low-frequency phase slopes ±pi/2.
  Then compute cross-N refinement chains and Sref.

10.16z:
  Accept anchoring only if:
    RevA true pass,
    no RevA control pass,
    low refinement instability,
    distance to nearest zeta zero <= 0.5.
  Strict promotion additionally requires Sref >= 0.15.

No RH proof or Hilbert-Polya claim is made.

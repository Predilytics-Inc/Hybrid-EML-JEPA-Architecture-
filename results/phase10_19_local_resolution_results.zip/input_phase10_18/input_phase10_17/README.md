Phase 10.17: out-of-sample validation of the phase-locked strict anchor.

Fixed law:
  plock_m010_p100_k1_phi0_s_halfpi

No retuning:
  phi0, slope, lambda, pmax, kmax, determinant parameters, and anchor thresholds are fixed.

OOS tests:
  Three new prime-cutoff sets:
    OOS_C = {2500, 8000, 25000, 85000}
    OOS_D = {4000, 12000, 40000, 120000}
    OOS_E = {1500, 6000, 18000, 65000}
  Three window sets:
    base, shift5, shift10
  N-refinement extended to:
    N = {20, 24, 28, 32}

Strict OOS anchor:
  RevA true pass,
  no RevA control pass,
  low refinement instability across N=20,24,28,32,
  distance to nearest zeta zero <= 0.5,
  Sref >= 0.15,
  N=32 present and stable.

Overall PASS requires all three OOS P-sets to have at least one strict Sref anchor.
This is still experimental validation, not an RH proof.

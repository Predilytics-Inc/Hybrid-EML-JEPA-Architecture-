Phase 10.19 — Local Resolution Refinement

10.19a:
  Targets were selected from Phase 10.18 strict Sref accepted strong-pass branches with delta <= 0.1.

10.19b:
  Around each target mean_t, local windows [mean_t-1, mean_t+1] were sampled at:
    h = 0.25, 0.125, 0.0625, 0.03125.

10.19c:
  The determinant phase was recomputed locally for fixed law:
    plock_m010_p100_k1_phi0_s_halfpi
  with no parameter retuning.
  Candidates were reconstructed from local phase windings and continued across:
    N = 20, 24, 28, 32
  using OT and DTW continuation objectives.
  Zeta-zero distance was not used in branch construction.

10.19z:
  After branch construction, nearest-zero distance, drift, Sref, and acceptance gates were computed.
  Controls were run for:
    phase_shuffled, wrong_sign, random_trace_zero, projection_only.

Key acceptance:
  accepted branch = true model, low refinement instability, delta <= 0.5, Sref >= 0.15.
  strong resolution pass = accepted branch reaches delta <= 0.01.
  major pass = monotone improvement as h decreases to delta <= 0.01.

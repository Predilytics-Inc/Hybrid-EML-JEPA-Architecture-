# Phase-bearing arithmetic Cij operator kernel rerun

Critical diagnostic was run first.

Kernel: K_ij(t)=a_i a_j C_ij exp(i(phi_i(t)-phi_j(t))).

Cij options: A log-distance, B prime-gap, C von-Mangoldt weighted, D hybrid.

Result: K(t)=D_phi(t) B D_phi(t)^(-1), B=diag(a) C diag(a). Hence eigenvalues are invariant over t. The requested phase-difference kernel cannot produce eigenvalue reordering by changing only Cij.

No macro ADL retuning. No Q5/Q6/Q6.1 threshold changes. No zeta-zero anchoring.

Integrated gate: Q5 pass AND Q6 pass AND Q6.1 pass.
Overall verdict: FAIL.
